import requests
import json
METEO_API_KEY = "88322e7d011c1c3eb3939bdba79eb177"
#content=requests.get(url)
#data=content.json()
if METEO_API_KEY is None:
    # URL de test :
    METEO_API_URL = "https://samples.openweathermap.org/data/2.5/forecast?lat=0&lon=0&appid=xxx"
else:
    # URL avec clé :
    METEO_API_URL = "https://api.openweathermap.org/data/2.5/forecast?lat=48.883587&lon=2.333779&appid=" + METEO_API_KEY
response = requests.gets(METEO_API_URL)
content = json.loads(response.content.decode('utf-8'))
if response.status_code != 200:
    print( 'statusCode : error')
    print( 'The api request failled. go back to response')

"""
return jsonify({
    'status': 'error',
    'message': 'La requête à l\'API météo n\'a pas fonctionné. Voici le message renvoyé par l\'API : {}'.format(content['message'])
    }), 500
"""

data = [] # On initialise une liste vide
for prev in content["list"]:
    datetime = prev['dt'] * 1000
    temperature = prev['main']['temp'] - 273.15 # Conversion de Kelvin en °c
    temperature = round(temperature, 2)
    humidity = prev['main']['humidity']
    pressure = prev['main']['pressure']
    data.append([datetime, temperature])
print('statusCode: ok')
print(datetime)

"""
return jsonify({
    'status': 'ok',
     'data': data
})
"""

